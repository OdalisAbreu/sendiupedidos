<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Nuevo Pedido</title>
</head>
<body>
	<h1>Hola Mundo</h1>
</body>
</html>