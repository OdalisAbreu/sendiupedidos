<?php $__env->startSection('title', 'Listado de categorias'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>
<div class="header header-filter" style="background-image: url(<?php echo e(asset('/public/img/bg1.jpg')); ?>);">
</div>

<div class="main main-raised">
    <div class="container">        

        <div class="section text-center">
            <div class="row">
                <div class="col-sm-9 text-center">
                                <h2 class="title">Listado de categorias</h2>
                </div>
                <div class="col-sm-3">
                    <a href ="<?php echo e(url('/admin/categories/create')); ?>" class="btn btn-primary btn-just-icon" title="Nueva categoria">
                        <i class="material-icons">note_add</i>
                    </a>                   
                </div>
            </div>

            <?php if(Session::has('msg')): ?>
                <div class="alert alert-info">
                  <strong> <?php echo e(Session::get('msg')); ?></strong>
                </div>
           
            <?php endif; ?>


            <div class="team">
                <div class="row">    
                    

                    <table class="table">
                        <thead>
                            <tr>
                                <th class="text-center">#</th>
                                <th class="col-md-2 text-center">Nombre</th>
                                <th class='col-md-5 text-center'>Descripción</th>                               
                                <th>Imágen</th>                               
                                <th class="text-right">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-center"><?php echo e($category->id); ?></td>
                            <td><?php echo e($category->name); ?></td>
                            <td><?php echo e($category->description); ?></td>
                            <td>
                                <img src="<?php echo e($category->featured_image_url); ?>" class="img-rounded" height="50px" width="50px">
                            </td>
                            <td class="td-actions text-right">
                              
                              <form method="post" action="<?php echo e(url('/admin/categories/'.$category->id )); ?>">
                              <?php echo e(csrf_field()); ?>

                              <?php echo e(method_field('DELETE')); ?>

                                <!--
                                <a rel="tooltip" title="Ver Categoria" class="btn btn-info btn-simple btn-xs">
                                    <i class="fa fa-info"></i>
                                </a>
                                -->
                                <a  href="<?php echo e(url('/admin/categories/'.$category->id.'/edit')); ?>" rel="tooltip" title="Editar Categoria" class="btn btn-success btn-simple btn-xs">
                                    <i class="fa fa-edit"></i>
                                </a>                                   
                                
                                <!--
                                 <a href="<?php echo e(url('/admin/categories/'.$category->id.'/images')); ?>" rel="tooltip" title="Imágen de la categoría" class="btn btn-warning btn-simple btn-xs">
                                    <i class="fa fa-image"></i>
                                </a>
                                -->
                                    <button type="submit" rel="tooltip" title="Eliminar" class="btn btn-danger btn-simple btn-xs">
                                        <i class="fa fa-times"></i>
                                    </button>
                                </form>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                    <?php echo e($categories->links()); ?>

                </div>
            </div>

        </div>


        
    </div>

</div>

<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>