<?php $__env->startSection('title', 'Listado de productos'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>


<?php $__env->startSection('content'); ?>

<div class="header header-filter" style="background-image: url(<?php echo e(asset('/img/bg1.jpg')); ?>);">
</div>
<div class="main main-raised">
    <div class="container">
        <div class="section text-center">
            <table class="table table-success table-striped">
                <tr>
                    <th class="col-2 text-center"> Orden </th>
                    <th class="col-2 text-center"> Status </th>
                    <th class="col-2 text-center"> Nombre </th>
                    <th class="col-2 text-center"> Monto </th>
                    <th class="col-4 text-center"> Opciones </th>
                </tr>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="col-2"><?php echo e($order->id); ?></td>
                    <td class="col-2"><?php echo e($order->status); ?></td>
                    <td class="col-2"><?php echo e($order->user->name); ?></td>
                    <td class="col-2"> RD$ 500.00 </td>
                    <td class="col-4">
                        <a href="<?php echo e(url('orders/'.$order->id.'/Enviado')); ?>" class="btn btn-info"> Enviar </a>
                        |  
                        <a href="<?php echo e(url('orders/'.$order->id.'/Entregado')); ?>" class="btn btn-success"> Entregar </a>
                        |
                        <a href="<?php echo e(url('orders/'.$order->id.'/Cancelado')); ?>" class="btn btn-danger"> Cancelar </a> 
                     <!-------   | <a href="#" class="btn btn-primary"> Ver pedido </a> -->
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>



<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>