<?php $__env->startSection('title', 'Listado de productos'); ?>

<?php $__env->startSection('body-class', 'product-page'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $map['js']; ?>


<div class="header header-filter" style="background-image: url(<?php echo e(asset('/public/img/bg1.jpg')); ?>);">
</div>
<div class="main main-raised">
    <div class="container">
        <div class="section text-center">
            
            <?php echo $map['html']; ?>

         </div>
    </div>
</div>


<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SendiuPedidos\resources\views/admin/orders/map.blade.php ENDPATH**/ ?>