<?php $__env->startSection('title', 'App Shop | Dashboard'); ?>

<?php $__env->startSection('body-class', 'profile-page'); ?>

<?php $__env->startSection('styles'); ?>
    <style>
            
         .team {
            margin-bottom: 50px;
         }
         .row {
            margin-top: 20px;
         }
    /*not(:first-child) */

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
<div class="header header-filter" style="background-image: url('/public/images/img2.jpg');"></div>

<div class="main main-raised">
<div class="profile-content">
    <div class="container">
        <div class="rows">
            <div class="profile">
                <div class="avatar">
                    <img src="<?php echo e($category->featured_image_url); ?>" alt="Imágen representativa de la categoria <?php echo e($category->name); ?>" class="img-rounded img-responsive">
                </div>
                <div class="name">
                    <h3 class="title"><?php echo e($category->name); ?></h3>                   
                </div>

                 <?php if(session('msg')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('msg')); ?>

                        </div>
                <?php endif; ?>
                
            </div>
        </div>
        <div class="description text-center">
            <p><?php echo e($category->description); ?> </p>
        </div>
    
            
           <div class="team text-center">
                      <div class="row">
                               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php if(!($key % 3) and $key > 0): ?>
                                </div>
                                <div class="row">
                                <?php endif; ?>
                                
                                <div class="col-md-4">
                                 <div class="team-player">
                                <img src="<?php echo e($product->featured_image_url); ?>" alt="Thumbnail Image" class="img-rounded img-responsive">
                                        <h4 class="title">
                                       <a href="<?php echo e(url('/products/'. $product->id)); ?>"> <?php echo e($product->name); ?> </a> 
                                       
                                        </h4>
                                        <p class="description"><?php echo e($product->description); ?></p>
                                    </div>  
                                    </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>




               
     </div>
                
            </div>


       

    </div>
</div>
</div>

    


<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>