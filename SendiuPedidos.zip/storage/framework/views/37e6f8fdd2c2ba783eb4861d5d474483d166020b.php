<footer class="footer">
    <div class="container">
        <nav class="pull-left">
            <ul>
                <li>
                    <a href="https://sendiu.net/">
                        ¿Necesitas ayuda?
                    </a>
                </li>
                <li>
                    <a href="https://sendiu.net/contactanos/">
                       Asesoría personalizada
                    </a>
                </li>
                <li>
                    <a href="https://sendiu.net/desarrolladores-2/">
                       Integra Nuestra API
                    </a>
                </li>
                <li>
                    <a href="https://sendiu.net/sendiu-canales-digitales-empresa/">
                        Conocenos
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</footer>