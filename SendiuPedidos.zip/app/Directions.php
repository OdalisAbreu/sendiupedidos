<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Directions extends Model
{
    //
}
